package com.clipper.app

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Crop
import androidx.media3.transformer.*
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import java.io.File
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var go: Button
    private var len = 30
    private var ready = false

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun pill(c: Int, r: Int = 28) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20)); setBackgroundColor(Color.parseColor("#F6F4F2")) }
        fun tv(t: String, s: Float, bold: Boolean = false, c: String = "#1A1816") = TextView(this).apply { text = t; textSize = s; setTextColor(Color.parseColor(c)); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD) }
        root.addView(tv("✂️ Clipper", 16f, true))
        root.addView(tv("Buat Klip Otomatis", 28f, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        root.addView(tv("Tempel link video panjang, lalu jadikan klip vertikal siap upload ke TikTok, Reels, dan Shorts.", 15f, c = "#7A746D"))
        root.addView(tv("Tautan video", 16f, true).apply { setPadding(0, dp(20), 0, dp(8)) })
        input = EditText(this).apply { hint = "https://youtu.be/..."; setSingleLine(); background = pill(Color.WHITE, 12); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        root.addView(input)
        root.addView(Button(this).apply { text = "Tempel"; isAllCaps = false; setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            input.setText(cm.primaryClip?.getItemAt(0)?.text ?: "") } })
        root.addView(tv("Durasi tiap klip", 16f, true).apply { setPadding(0, dp(16), 0, dp(8)) })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf(15, 30, 45, 60).forEach { n -> rg.addView(RadioButton(this).apply { text = "$n dtk"; id = n; isChecked = n == 30 }) }
        rg.setOnCheckedChangeListener { _, id -> len = id }
        root.addView(rg)
        go = Button(this).apply { text = "Lanjutkan"; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f; background = pill(Color.parseColor("#1F1B18"), 28); setOnClickListener { start() } }
        root.addView(go, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(20) })
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        status = tv("Menyiapkan mesin unduh…", 14f, c = "#7A746D")
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })

        intent?.getStringExtra(android.content.Intent.EXTRA_TEXT)?.let { input.setText(it) }
        lifecycleScope.launch(Dispatchers.IO) {
            try { YoutubeDL.getInstance().init(application); FFmpeg.getInstance().init(application); ready = true; ui("Siap. Tempel link lalu tekan Lanjutkan.") }
            catch (e: Exception) { ui("Gagal menyiapkan mesin: ${e.message}") }
        }
    }

    private suspend fun ui(msg: String, pct: Int? = null) = withContext(Dispatchers.Main) { status.text = msg; if (pct != null) bar.progress = pct }

    private fun start() {
        val url = input.text.toString().trim()
        if (!ready) { status.text = "Mesin belum siap, tunggu sebentar."; return }
        if (!url.startsWith("http")) { status.text = "Link tidak valid."; return }
        go.isEnabled = false
        lifecycleScope.launch(Dispatchers.IO) {
            try { process(url) } catch (e: Throwable) { ui("Gagal: ${e.message}", 0) }
            withContext(Dispatchers.Main) { go.isEnabled = true }
        }
    }

    private suspend fun process(url: String) {
        val dir = File(cacheDir, "kerja").apply { deleteRecursively(); mkdirs() }
        ui("Mengunduh video…", 0)
        val req = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("-f", "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720][ext=mp4]/b[height<=720]/b")
            addOption("--merge-output-format", "mp4")
            addOption("-o", dir.absolutePath + "/src.%(ext)s")
        }
        YoutubeDL.getInstance().execute(req, "clip") { p, _, _ -> lifecycleScope.launch { ui("Mengunduh video… ${p.toInt()}%", (p * 0.4f).toInt()) } }
        val src = dir.listFiles()!!.first { it.name.startsWith("src.") }
        val mr = MediaMetadataRetriever().apply { setDataSource(src.absolutePath) }
        val total = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
        var w = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toFloat()
        var h = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toFloat()
        val rot = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        mr.release()
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val f = (9f * h) / (16f * w)
        val starts = generateSequence(0L) { it + len * 1000L }.takeWhile { total - it >= 5000 }.take(20).toList()
        starts.forEachIndexed { i, s ->
            ui("Memotong klip ${i + 1} dari ${starts.size}…", 40 + (60 * i / starts.size))
            val out = File(dir, "klip_${i + 1}.mp4")
            cut(src, out, s, minOf(total, s + len * 1000L), f)
            save(out, "Clipper_${System.currentTimeMillis()}_${i + 1}.mp4")
            out.delete()
        }
        ui("Selesai! ${starts.size} klip tersimpan di galeri (folder Movies/Clipper).", 100)
    }

    private suspend fun cut(src: File, out: File, s: Long, e: Long, f: Float) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { c ->
            val item = MediaItem.Builder().setUri(Uri.fromFile(src))
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()).build()
            val vfx: List<Effect> = if (f < 1f) listOf(Crop(-f, f, -1f, 1f)) else listOf()
            val edited = EditedMediaItem.Builder(item).setEffects(Effects(listOf(), vfx)).build()
            Transformer.Builder(this@MainActivity).setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { c.resume(Unit) }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { c.resumeWith(Result.failure(exportException)) }
                }).build().start(edited, out.absolutePath)
        }
    }

    private fun save(f: File, name: String) {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipper")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    }
}
